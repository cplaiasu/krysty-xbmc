import xbmc, xbmcaddon
import os, re
try:
	try: import cPickle as pickle
	except: import pickle
except: pass


addonId = 'plugin.video.990'

selfAddon = xbmcaddon.Addon(id=addonId)

print "%s v%s" % (addonId, selfAddon.getAddonInfo('version'))


def getPluginPath():
	return xbmc.translatePath(selfAddon.getAddonInfo('path'))

def getSetting(settingId):
	return selfAddon.getSetting(settingId)
	
def openSettings():
	selfAddon.openSettings()

def saveData(filename, data):
	profilePath = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
	try:
		os.makedirs(profilePath)
	except:
		pass
	savePath = os.path.join(profilePath, filename)
	try:
		pickle.dump(data, open(savePath, 'wb'))
		return True
	except pickle.PickleError:
		return False


def loadData(filename):
	profilePath = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
	loadPath = os.path.join(profilePath, filename)
	if not os.path.isfile(loadPath):
		return False
	try:
		data = pickle.load(open(loadPath))
	except:
		return False
	return data


def ro2en(string):
	dict = {
			'Actiune':		'Action',
			'Animatie':		'Animation',
			'Aventura':		'Adventure',
			'Biografie':	'Biography',
			'Comedie':		'Comedy',
			'Crima':		'Crime',
			'Documentar':	'Documentary',
			'Dragoste':		'Romance',
			'Familie':		'Family',
			'Fantezie':		'Fantasy',
			'Istorie':		'History',
			'Mafie':		'Mafia',
			'Mister':		'Mystery',
			'Razboi':		'War',
			'Sarbatori':	'Holidays',
			'S.F.':			'Sci-Fi'
	}
	try:
		string = string.strip()
		string = re.compile(r'\b(' + '|'.join(dict.keys()) + r')\b').sub(lambda x: dict[x.group()], string)
	except:
		pass
	return string
