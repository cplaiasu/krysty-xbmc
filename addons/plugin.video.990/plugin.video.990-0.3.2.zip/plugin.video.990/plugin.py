import xbmc, xbmcaddon
import os
try:
	try: import cPickle as pickle
	except: import pickle
except: pass



addonId = 'plugin.video.990'

selfAddon = xbmcaddon.Addon(id=addonId)

print "%s v%s" % (addonId, selfAddon.getAddonInfo('version'))


def getPluginPath():
	pluginPath = xbmc.translatePath(selfAddon.getAddonInfo('path'))
	return pluginPath

	
def saveData(filename, data):
	profilePath = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
	try:
		os.makedirs(profilePath)
	except:
		pass
	savePath = os.path.join(profilePath, filename)
	try:
		pickle.dump(data, open(savePath, 'wb'))
		return True
	except pickle.PickleError:
		return False

		
def loadData(filename):
	profilePath = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
	loadPath = os.path.join(profilePath, filename)
	if not os.path.isfile(loadPath):
		return False
	try:
		data = pickle.load(open(loadPath))
	except:
		return False
	return data