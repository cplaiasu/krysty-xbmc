"""
    990.ro XBMC Addon
    Copyright (C) 2012-2014 krysty
	https://code.google.com/p/krysty-xbmc/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
"""

import sys, os, string, re
import urllib, urllib2
import xbmc, xbmcplugin, xbmcgui
import plugin, db
from resources.lib.BeautifulSoup import BeautifulSoup
import HTMLParser
from resources.lib.ga import track


siteUrl = 'http://www.990.ro/'
searchUrl = 'http://www.990.ro/functions/search3/live_search_using_jquery_ajax/search.php'

USER_AGENT = 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36'
ACCEPT = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'

pluginPath = plugin.getPluginPath()

TVshowsIcon = os.path.join(pluginPath, 'resources', 'media', 'tvshowsicon.png')
MoviesIcon = os.path.join(pluginPath, 'resources', 'media', 'moviesicon.png')
SearchIcon = os.path.join(pluginPath, 'resources', 'media', 'searchicon.png')
InfoIcon = os.path.join(pluginPath, 'resources', 'media', 'inficon.png')

track()

DB = db.DB()

def MAIN():
	addDir('TV Shows',siteUrl,4,TVshowsIcon)
	addDir('Movies',siteUrl,10,MoviesIcon)
	addDir('Search',siteUrl,22,SearchIcon)
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def TVSHOWS(url):
	AZ = (ltr for ltr in string.ascii_uppercase)
	
	addDir('All',url,1,TVshowsIcon)
	addDir('Last Added',url,5,TVshowsIcon)
	addDir('Search',url,21,TVshowsIcon)
	addDir('1-9',url,30,TVshowsIcon)
	for character in AZ:
		addDir(character,url,30,TVshowsIcon)
		
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	

def getTVshows(url,order=None):
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	progress.update(1, "", "", "")
	
	soup = BeautifulSoup(http_req(url))
	div = htmlFilter(str(soup.find("div", {"id": "sub1"})))
		
	if order:
		tvs = re.compile('href="seriale-(.+?)-online-download\.html" title=".+?">(['+order+'].+?)<\/a>').findall(div)
	else:
		tvs = re.compile('href="seriale-(.+?)-online-download\.html" title=".+?">(.+?)<\/a>').findall(div)
	
	count = 1
	current = 0
	total = len(tvs)

	while current <= total - 1:
		title = tvs[current][1]
		link = url+'seriale-'+tvs[current][0]+'-online-download.html'
		
		watched = 6
		if DB.succes:
			tvshowInfo = DB.check_watched('tvshows', title.lower())
			if tvshowInfo: watched = tvshowInfo['overlay']
		
		addDir(str(count)+'. '+title,link,2,overlay=watched)
		current = current + 1
		
		percent = int((count * 100) / total)
		message = "Loading TV Show " + str(count) + " of " + str(total)
		progress.update(percent, "", message, "")
		if progress.iscanceled(): sys.exit()
		
		count = count + 1
	
	progress.close()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

		
def getSeasons(tvshow, url):
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	progress.update(1, "", "", "")
	
	seasons = re.compile('<img src=\'.+?\' alt=\'Sezonul (.+?)\'>').findall(http_req(url))
	thumb = re.compile('<img src=\'../(.+?)\'').findall(http_req(url))
	if thumb: thumbnail = siteUrl+thumb[0]
	else: thumbnail = ''
	
	total = len(seasons)
	count = 1

	while count <= total:

		for season in seasons:
			
			watched = 6
			if DB.succes:
				name = re.sub('\(.+?\)',"",re.sub('\d+\.',"",tvshow)).lower().strip()
				tvshowInfo = DB.check_watched('seasons', name, int(season))
				if tvshowInfo: watched = tvshowInfo['overlay']
			
			season_nr = str(season).zfill(2)
			
			addDir('Season '+season_nr,url,3,thumbnail,tvshow,season_nr,overlay=watched)
			
			percent = int((count * 100) / total)
			message = "Loading season " + str(count) + " of " + str(total)
			progress.update( percent, "", message, "" )
			if progress.iscanceled(): sys.exit()
			
			count = count + 1
			
	progress.close()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

		
def getEpisodes(tvshow_url,season,videotitle,thumbnail):
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	progress.update(1, "", "", "")


	soup = BeautifulSoup(http_req(url))
	div = htmlFilter(str(soup.find("div", {"id": "content"})), True)

	episodes = re.compile('Sezonul '+season+', Episodul (.+?)<\/div>.+?<a href="seriale2-([\d]+-[\d]+)-.+?\.html" class="link">(.+?)<\/a>').findall(div)

	if episodes:
		total = len(episodes)
	else:
		episodes = re.compile('ma;">([\d]+)<\/div>.+?<a href="seriale2-([0-9]+-[0-9]+)-.+?\.html" class="link">(.+?)<\/a>').findall(div)
		total = len(episodes)

	count = 1

	while count <= total:
		
		for ep_num, ep_href, ep_name in episodes:
		
			if ep_name == str(re.findall('(Episodul [-0-9]*)',ep_name)).strip('[]').strip('"\''): ep_name = ''
			link = siteUrl+'player-serial-'+ep_href+'-sfast.html'
			
			watched = 6
			if DB.succes:
				tvshow = re.sub('\(.+?\)',"",videotitle).lower().strip()
				tvshowInfo = DB.check_watched('episodes', tvshow, int(season), ep_num)
				if tvshowInfo: watched = tvshowInfo['overlay']
			
			name = 'Episode '+ep_num+' '+ep_name
			vtitle = videotitle+' '+season+'x'+str(ep_num)
			
			addDir(name,link,8,thumbnail,vtitle,season,ep_num,watched,False)
			
			percent = int((count * 100) / total)
			message = "Loading episode " + str(count) + " of " + str(total)
			progress.update(percent, "", message, "")
			if progress.iscanceled(): sys.exit()
			
			count = count + 1

	progress.close()

	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	

def lastAdded(cat):
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	progress.update(1, "", "", "")

	soup = BeautifulSoup(http_req(siteUrl))
	div = htmlFilter(str(soup.findAll("div", {"id": "tab1"})), True)
	
	if cat == 'seriale':
		results = re.compile('<a class="link" href="(seriale2)-([0-9]+-[0-9]+)-.+?\.html">(.+?)<\/a>.+?">(.+?)<\/div><\/div>').findall(div)
	elif cat == 'filme':
		results = re.compile('<a class="link" href="(filme)-(.+?)\.html">(.+?)<\/a>.+?">(.+?)<\/div>').findall(div)
	
	total = len(results)
	count = 1

	while count <= total:
			
		for type, link, title, ep_year in results:
		
			watched = 6
			
			if type == 'seriale2':
				eps = re.compile('S(\d+)E(\d+)').findall(ep_year)
				if eps:
					season = eps[0][0]
					episode = eps[0][1]
				else:
					season = ''
					episode = ''
					
				if DB.succes:
					videoInfo = DB.check_watched('episodes', title.lower(), int(season), episode)
					if videoInfo: watched = videoInfo['overlay']
				
				name = str(count)+'. '+season+'x'+episode+' '+title
				url = siteUrl+'player-serial-'+link+'-sfast.html'
				videotitle = title+' '+season+'x'+episode
				
				addDir(name,url,8,"",videotitle,season,episode,watched,False)
			
			elif type == 'filme':
				year = re.compile('(\d{4,4})').findall(ep_year)
			
				if DB.succes:
					videoInfo = DB.check_watched('movies', title.lower())
					if videoInfo: watched = videoInfo['overlay']
				
				name = str(count)+'. '+title+' ('+year[0]+')'
				url = siteUrl+'filme-'+link+'.html'
				
				addDir(name,url,8,"",title+' ('+ep_year+')',overlay=watched,folder=False)

			percent = int((count * 100) / total)
			message = "Loading item " + str(count) + " of " + str(total)
			progress.update(percent, "", message, "")
			if progress.iscanceled(): sys.exit()
			
			count = count + 1
	
	progress.close()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	

def MOVIES(url,order=None):	
	if order == 'year':
		years = re.compile('<a href="filme2-(.+?)" title="[0-9]+">Filme (.+?)<\/a>').findall(http_req(url))
		for link, year in years:
			addDir(str(year),url+'filme2-'+link,9,MoviesIcon)
	
	elif order == 'genre':
		genres = re.compile('<a href="filme-(.+?)" title=".+?">(.+?)<\/a>').findall(http_req(url))
		for link, genre in genres:
			addDir(str(plugin.ro2en(genre)),url+'filme-'+link,9,MoviesIcon)
	
	else:
		addDir('Search',url,20,MoviesIcon)
		addDir('Last Added',url,6,MoviesIcon)
		addDir('By Year',url,11,MoviesIcon)
		addDir('By Genre',url,12,MoviesIcon)
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def getMovies(url):
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	progress.update(5, "", "Loading list - 5%", "")

	soup = BeautifulSoup(http_req(url))
	div = str(soup.find("div", {"id": "numarpagini"}))
	movies = re.compile('([\d]+)<\/a>').findall(div)
	pages = [int(x) for x in movies]
	maxpage = max(pages)
	
	count = 1
	page = 1
	total_movies = ""

	while count < total_movies:
	
		while page <= maxpage:
			url = re.sub('-\d\.+', '-'+str(page)+'.', url)

			soup = BeautifulSoup(http_req(url))
			div = htmlFilter(str(soup.find("div", {"id": "content"})), True)
			movies = re.compile('<a href="filme-(.+?)-online-download\.html" .+? class="link">(.+?)<\/a> \(([\d]+)\)').findall(div)
			thumb = re.compile('<img src="../(.+?)"').findall(div)
			
			current = 0
			total_movies = len(movies) * maxpage

			while current <= len(movies) - 1:
				name = str(count)+'. '+movies[current][1]+' ('+movies[current][2]+')'
				link = siteUrl+'filme-'+movies[current][0]+'-online-download.html'
				thumbnail = siteUrl+thumb[current]
				videotitle = re.sub('[0-9]+\. ', "", name)
				
				watched = 6
				if DB.succes:
					movie_name = str(movies[current][1]).lower()
					movieInfo = DB.check_watched('movies', movie_name)
					if movieInfo: watched = movieInfo['overlay']
				
				addDir(name,link,8,thumbnail,videotitle,overlay=watched,folder=False)
				
				current = current + 1
				
				percent = int((count * 100) / total_movies)
				if page == maxpage: percent = 100
				message = "Loading list - " + str(percent) + "%"
				progress.update(percent, "", message, "")
				if progress.iscanceled(): sys.exit()
				
				count = count + 1
			
			page = page + 1
	
	progress.close()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
		
	
def SEARCH(cat):
	lastSearch = None
	kb = xbmc.Keyboard('', 'Search', False)
	try:
		lastSearch = plugin.loadData('search')
		if lastSearch: kb.setDefault(lastSearch)
	except: pass
	kb.doModal()
	if (kb.isConfirmed()):
		inputText = kb.getText()
		try: plugin.saveData('search', inputText)
		except: pass
		if inputText == '':
			dialog = xbmcgui.Dialog().ok('Search', 'There is nothing to search.')
			sys.exit()
		else:
			progress = xbmcgui.DialogProgress()
			progress.create('Progress', 'Please wait...')
			progress.update(1, "", "", "")
			
			searchText = {'kw': inputText}
			data = urllib.urlencode(searchText)
			req = urllib2.Request(searchUrl, data, headers = {'User-Agent': USER_AGENT})
			response = htmlFilter(urllib2.urlopen(req).read())
			
			if cat == 'all':
				results = re.compile('<a href="(.+?)-(.+?)-online-download\.html">.+?<div id="rest">(.+?)<div id="auth_dat">').findall(response)
				thumb = re.compile('<img class="search" .+? src="../(.+?)"').findall(response)
			else:
				results = re.compile('<a href="('+cat+')-(.+?)-online-download\.html">.+?<div id="rest">(.+?)<div id="auth_dat">').findall(response)
				thumb = re.compile('<a href="'+cat+'-.+?<img class="search" .+? src="../(.+?)"').findall(response)
			
			total = len(results)
			count = 1
			
			while count <= total:

				current = 0
				
				while current <= total - 1:
					
					if results[current][0] == 'seriale':					
						name = re.sub('\(', ' (', str(count)+'. '+results[current][2])
						url = siteUrl+'seriale-'+results[current][1]+'-online-download.html'
						thumbnail = siteUrl+thumb[current]
						videotitle = re.sub('[0-9]+\. ', "", name)
						
						watched = 6
						if DB.succes:
							tvshow = re.sub('\(.+?\)', '', results[current][2]).lower().strip()
							movieInfo = DB.check_watched('tvshows', tvshow)
							if movieInfo: watched = movieInfo['overlay']
						
						addDir(name,url,2,thumbnail,videotitle,overlay=watched)
					
					elif results[current][0] == 'filme':						
						name = re.sub('\(', ' (', str(count)+'. '+results[current][2])
						url = siteUrl+'filme-'+results[current][1]+'-online-download.html'
						thumbnail = siteUrl+thumb[current]
						videotitle = re.sub('[0-9]+\. ', "", name)
						
						watched = 6
						if DB.succes:
							movieName = re.sub('\(.+?\)', '', results[current][2]).lower().strip()
							movieInfo = DB.check_watched('movies', movieName)
							if movieInfo: watched = movieInfo['overlay']
						
						addDir(name,url,8,thumbnail,videotitle,overlay=watched,folder=False)
					
					current = current + 1

					percent = int((count * 100) / total)
					message = "Loading " + str(count) + " of " + str(total)
					progress.update( percent, "", message, "" )
					
					count = count + 1
					
			progress.close()
	
	else: sys.exit()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def http_req(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	req.add_header('Accept', ACCEPT)
	response = urllib2.urlopen(req)
	source = response.read()
	response.close()
	return source

	
def youtube_video(url):
	try:
		conn = urllib2.urlopen(url)
		encoding = conn.headers.getparam('charset')
		content = conn.read().decode(encoding)
		s = re.findall(r'"url_encoded_fmt_stream_map": "([^"]+)"', content)
		if s:
			s = s[0].split(',')
			s = [a.replace('\\u0026', '&') for a in s]
			s = [urllib2.parse_keqv_list(a.split('&')) for a in s]
			n = re.findall(r'<title>(.+) - YouTube</title>', content)
			s, n = (s or [], HTMLParser.HTMLParser().unescape(n[0]))
			for z in s:
				if z['itag'] == '18':
					if 'mp4' in z['type']:
						ext = '.mp4'
					elif 'flv' in z['type']:
						ext = '.flv'
					try: link = urllib.unquote(z['url'] + '&signature=%s' % z['sig'])
					except: link = urllib.unquote(z['url'])
			return link
	except: return False

	
def playStream(url,videotitle,thumbnail,season='',episode=''):
	try:
		title = re.sub('\(.+?\)', "", videotitle).lower().strip()
		win = xbmcgui.Window(10000)
		win.setProperty('990.playing.title', title)
		win.setProperty('990.playing.season', str(season))
		win.setProperty('990.playing.episode', str(episode))
	except: pass
	item = xbmcgui.ListItem(videotitle, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
	item.setInfo(type = "Video", infoLabels = {"title": videotitle})
	item.setPath(url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	return True


def selectSource(url,videotitle='',thumbnail='',season='',episode=''):
	sources = getSources(url)
	if not sources:
		return xbmcgui.Dialog().ok("", "Error: video link(s) not available!")
	else:
		labels = []
		for item in sources:
			labels.append(item['title'])
		dialog = xbmcgui.Dialog()
		index = dialog.select('Choose your stream', labels)
		if index > -1:
			if re.search('trailer', sources[index]['title'], re.IGNORECASE):
				videotitle = videotitle + ' Trailer'
			playStream(sources[index]['url'], videotitle, thumbnail, season, episode)
		else:
			return
	
	
def getSources(url):
	sources = []
	try:
		quality = ''
		if(re.search('filme', url)):
			quality = re.compile('Calitate film: nota <b>(.+?)</b>').findall(http_req(url))
			movieId = re.search('-([\d]+)-', url)
			
			trailer_link = False
			trailerframe = re.compile('<iframe width=\'595\' height=\'335\' src=\'.+?\/embed\/(.+?)\'').findall(http_req(url))
			if trailerframe:
				yt = youtube_video('http://www.youtube.com/watch?v='+trailerframe[0])
				if yt:
					trailer_link = yt

			if trailer_link:
				item = {'title': 'Play Trailer', 'url': trailer_link+'?.mp4'}
				sources.append(item)

			url = siteUrl+'player-film-'+movieId.group(1)+'-sfast.html'

		match = re.compile('http:\/\/fastupload\.?r?o?l?\.ro\/?v?i?d?e?o?\/(.+?)\.html').findall(http_req(url))
		url = 'http://superweb.rol.ro/video/'+match[0]+'.html'
		match = re.compile('\'file\': \'(.+?)\',').findall(http_req(url))
		videoLink = match[0]+'|referer='+url
		if(quality == ''):
			item = {'title': 'Play Video', 'url': videoLink}
		else:
			item = {'title': 'Play Video (Quality:'+quality[0]+')', 'url': videoLink}
		sources.append(item)
		return sources
	except:
		return False


def addDir(name,url,mode,thumbnail='',videotitle='',season='',episode='',overlay=6,folder=True):
	ok = True
	params = {'name': name, 'mode': mode, 'url': url, 'thumbnail': thumbnail}
	
	params['videotitle'] = videotitle
	params['season'] = season
	params['episode'] = episode
	
	if overlay == 6: playcount = 0
	elif overlay == 7: playcount = 1
	liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
	if not folder:
		liz.setProperty('isPlayable', 'true')
		liz.setProperty('resumetime', str(0))
		liz.setProperty('totaltime', str(1))
	liz.setInfo(type="Video", infoLabels = {"title": name, "playcount": playcount, "overlay": overlay})
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = set_params(params), listitem = liz, isFolder = folder)
	return ok

	
def htmlFilter(htmlstring, trimspaces = False):
	hex_entity_pat = re.compile('&#x([^;]+);')
	hex_entity_fix = lambda x: hex_entity_pat.sub(lambda m: '&#%d;' % int(m.group(1), 16), x)
	htmlstring = str(BeautifulSoup(hex_entity_fix(htmlstring), convertEntities=BeautifulSoup.ALL_ENTITIES))
	if trimspaces:
		htmlstring = "".join(line.strip() for line in htmlstring.split("\n"))
	return htmlstring


def set_params(dict):
	out = {}
	for key, value in dict.iteritems():
		if isinstance(value, unicode):
			value = value.encode('utf8')
		elif isinstance(value, str):
			value.decode('utf8')
		out[key] = value
	return sys.argv[0] + '?' + urllib.urlencode(out)
	
	
def get_params():
	param = {'default': 'none'}
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
			params = sys.argv[2]
			cleanedparams = params.replace('?','')
			if (params[len(params)-1] == '/'):
				params = params[0:len(params)-2]
			pairsofparams = cleanedparams.split('&')
			param = {}
			for i in range(len(pairsofparams)):
				splitparams = {}
				splitparams = pairsofparams[i].split('=')
				if (len(splitparams)) == 2:
					param[splitparams[0]] = splitparams[1]
	return param
	

params = get_params()

mode = int(params.get('mode', 0))
url = urllib.unquote_plus(params.get('url', ''))
name = urllib.unquote_plus(params.get('name', ''))
videotitle = re.sub('\d+\.',"", urllib.unquote_plus(params.get('videotitle', ''))).strip()
thumbnail = urllib.unquote_plus(params.get('thumbnail', ''))
season = urllib.unquote_plus(params.get('season', ''))
episode = urllib.unquote_plus(params.get('episode', ''))


if mode: print "Mode: "+str(mode)
if url: print "URL: "+str(url)


if mode == 0 or not url or len(url) < 1: MAIN()
elif mode == 1: getTVshows(url)
elif mode == 2: getSeasons(name,url)
elif mode == 3: getEpisodes(url,season,videotitle,thumbnail)
elif mode == 4: TVSHOWS(url)
elif mode == 5: lastAdded('seriale')
elif mode == 6: lastAdded('filme')
elif mode == 8: selectSource(url,videotitle,thumbnail,season,episode)
elif mode == 9: getMovies(url)
elif mode == 10: MOVIES(url)
elif mode == 11: MOVIES(url,order='year')
elif mode == 12: MOVIES(url,order='genre')
elif mode == 20: SEARCH('filme')
elif mode == 21: SEARCH('seriale')
elif mode == 22: SEARCH('all')
elif mode == 30: getTVshows(url,order=name)
