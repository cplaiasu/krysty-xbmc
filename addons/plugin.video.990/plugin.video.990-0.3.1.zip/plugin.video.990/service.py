import os
import xbmc, xbmcgui
import re

db_dir = os.path.join(xbmc.translatePath("special://database"), '990dotrocache.db')

try:
	try: from sqlite3 import dbapi2 as database
	except: from pysqlite2 import dbapi2 as database
except: pass


def convert_seconds(seconds):
	m, s = divmod(seconds, 60)
	h, mins = divmod(m, 60)
	if m > 60: return "%02d:%02d:%02d" % (h, mins, s)
	else: return "%02d:%02d" % (m, s)


def titlecase(s):
	return re.sub(r"[A-Za-z]+('[A-Za-z]+)?", lambda mo: mo.group(0)[0].upper() + mo.group(0)[1:].lower(), s)



class Service(xbmc.Player):
	def __init__(self, *args, **kwargs):
		xbmc.Player.__init__(self, *args, **kwargs)
		self.reset()

		self.last_run = 0
		
		try: xbmc.log('990.ro: Service starting...')
		except: pass

	
	def reset(self):
		try:
			try: xbmc.log('990.ro: Service: Resetting...')
			except: pass
			win = xbmcgui.Window(10000)
			win.clearProperty('990.playing.title')
			win.clearProperty('990.playing.season')
			win.clearProperty('990.playing.episode')
		except: pass

		self._totalTime = 999999
		self._lastPos = 0
		self._sought = False
		self.tracking = False
		self.video_type = ''
		self.video_table = ''
		self.title = ''
		self.season = ''
		self.episode = ''


	def check(self):
		win = xbmcgui.Window(10000)
		if win.getProperty('990.playing.title'): return True
		else: return False


	def onPlayBackStarted(self):
		try:	
			try: xbmc.log('990.ro: Service: Playback started')
			except: pass
			
			self._totalTime = self.getTotalTime()
			
			if int(self._totalTime) > 360:
			
				self.tracking = self.check()
				
				if self.tracking:
					
					xbmc.log('990.ro: Service: tracking progress...')
					win = xbmcgui.Window(10000)
					self.title = win.getProperty('990.playing.title')
					self.season = win.getProperty('990.playing.season')
					self.episode = win.getProperty('990.playing.episode')
					
					if self.season and self.episode: self.video_type = 'tvshow'
					else: self.video_type = 'movie'
					
					sql = 'SELECT bookmark FROM bookmarks WHERE video_type=? AND title=? AND season=? AND episode=?'
					
					db = database.connect(db_dir)
					cur = db.cursor()
					cur.execute(sql, (self.video_type, unicode(self.title, 'utf-8'), self.season, self.episode))
					bookmark = cur.fetchone()
					db.close()
					
					if bookmark:
						bookmark = float(bookmark[0])
						if not (self._sought and (bookmark - 30 > 0)):
							question = 'Resume %s from %s?' % (titlecase(self.title), convert_seconds(bookmark))
							resume = xbmcgui.Dialog()
							resume = resume.yesno(titlecase(self.title), '', question, '', 'Start from beginning', 'Resume')
							if resume: self.seekTime(bookmark)
							self._sought = True
					
		except: pass
		
		
	def onPlayBackStopped(self):
		try:
			try: xbmc.log('990.ro: Playback Stopped')
			except: pass
			
			if self.tracking:
				playedTime = int(self._lastPos)
				percent = int((playedTime / self._totalTime) * 100)
				
				pT = convert_seconds(playedTime)
				tT = convert_seconds(self._totalTime)
				try: xbmc.log('990.ro: Service: %s played of %s total = %s%%' % (pT, tT, str(percent)))
				except: pass
				
				if playedTime == 0 and self._totalTime == 999999:
					raise RuntimeError('XBMC silently failed to start playback')
				
				elif (percent > 85) and (self.video_type == 'movie' or (self.season and self.episode)):
					try: xbmc.log('990.ro: Service: Threshold met. Marking item as watched')
					except: pass
					
					sql = 'DELETE FROM bookmarks WHERE video_type=? AND title=? AND season=? AND episode=?'
					
					try:
						import db
						db.DB().change_watched(self.video_type, self.title, self.season, self.episode)
					except: pass
					
					db = database.connect(db_dir)
					cur = db.cursor()
					cur.execute(sql, (self.video_type, unicode(self.title, 'utf-8'), self.season, self.episode))
					db.commit()
					db.close()
					
					try:
						if self.video_type == 'tvshow':
							xbmc.sleep(1000)
							xbmc.executebuiltin("Action(back)")
							xbmc.sleep(1000)
							xbmc.executebuiltin("Container.Refresh")
					except: pass
				
				else:
					try: xbmc.log('990.ro: Service: Threshold not met. Saving bookmark')
					except: pass
					
					sql = 'INSERT OR REPLACE INTO bookmarks (video_type, title, season, episode, bookmark) VALUES (?,?,?,?,?)'
					
					db = database.connect(db_dir)
					cur = db.cursor()
					cur.execute(sql, (self.video_type, unicode(self.title, 'utf-8'), self.season, self.episode, playedTime))
					db.commit()
					db.close()
			
			self.reset()
		
		except: pass
		
		
	def onPlayBackEnded(self):
		try: xbmc.log('990.ro: Playback completed')
		except: pass
		self.onPlayBackStopped()



monitor = Service()

try:
	while not xbmc.abortRequested:
		while monitor.tracking and monitor.isPlayingVideo():
			monitor._lastPos = monitor.getTime()
			xbmc.sleep(1000)
		xbmc.sleep(1000)
	try: xbmc.log('990.ro: Service: Shutting Down...')
	except: pass
except: pass
