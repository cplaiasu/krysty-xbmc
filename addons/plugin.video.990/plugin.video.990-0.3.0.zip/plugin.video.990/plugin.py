import xbmc, xbmcaddon


addonId = 'plugin.video.990'



selfAddon = xbmcaddon.Addon(id=addonId)

print "%s v%s" % (addonId, selfAddon.getAddonInfo('version'))

def getPluginPath():
	pluginPath = xbmc.translatePath(selfAddon.getAddonInfo('path'))
	return pluginPath