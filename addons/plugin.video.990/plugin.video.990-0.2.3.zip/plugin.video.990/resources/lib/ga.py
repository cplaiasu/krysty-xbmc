from random import randint
from urllib import urlencode
from urllib2 import urlopen
from urlparse import urlunparse
from hashlib import sha1
from os import environ

def track():
	try:
		PROPERTY_ID = environ.get("GA_PROPERTY_ID", "UA-46834994-1")
		VISITOR = environ.get("GA_VISITOR", urlopen("http://myip.dnsdynamic.org/").read())
		VISITOR = str(int("0x%s" % sha1(VISITOR).hexdigest(), 0))[:10]
		PATH = "/"

		DATA = {"utmwv": "5.2.2d",
				"utmn": str(randint(1, 9999999999)),
				"utmp": PATH,
				"utmac": PROPERTY_ID,
				"utmcc": "__utma=%s;" % ".".join(["1", VISITOR, "1", "1", "1", "1"])}

		URL = urlunparse(("http",
						  "www.google-analytics.com",
						  "/__utm.gif",
						  "",
						  urlencode(DATA),
						  ""))
		urlopen(URL).info()
	except:
		pass
