"""
    990.ro XBMC Addon
    Copyright (C) 2012 krysty
	https://code.google.com/p/krysty-xbmc/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
"""

import sys, os, time
import urllib, urllib2
import re
import xbmc, xbmcplugin, xbmcgui, xbmcaddon


siteUrl = 'http://www.990.ro/'


addonId = 'plugin.video.990'
selfAddon = xbmcaddon.Addon(id=addonId)
pluginPath = xbmc.translatePath(selfAddon.getAddonInfo('path'))

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.2) Gecko/2008091620 Firefox/3.0.2'
ACCEPT = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'

TVshowsIcon = os.path.join(pluginPath, 'resources', 'media', 'tvshowsicon.png')
CartoonsIcon = os.path.join(pluginPath, 'resources', 'media', 'cartoonsicon.png')
MoviesIcon = os.path.join(pluginPath, 'resources', 'media', 'moviesicon.png')
SearchIcon = os.path.join(pluginPath, 'resources', 'media', 'searchicon.png')
InformationIcon = os.path.join(pluginPath, 'resources', 'media', 'inficon.png')

from resources.lib.BeautifulSoup import BeautifulSoup


def CATEGORIES():
	addDir('TV Shows',siteUrl,4,TVshowsIcon)
	addDir('Cartoons',siteUrl,5,CartoonsIcon)
	addDir('Movies',siteUrl,10,MoviesIcon)
	addDir('Search',siteUrl,22,SearchIcon)


def TVSHOWSORDER(url):
	addDir('All',url,1,TVshowsIcon)
	addDir('Search',url,21,TVshowsIcon)
	cat = ('1-9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z')
	for i in range(len(cat)):
		addDir(str(cat[i]),url,30,TVshowsIcon)
	

def get_tvshows(url,order=""):

	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	
	soup = BeautifulSoup(http_req(url))
	div = soup.find("ul", {"id": "ddsubmenu1"})
	
	i = 1
	a = ' '
	
	while i < a:
		
		if order:
			match = re.compile('href="seriale-(.+?)-online-download\.html" title=".+?".?>(['+order+'].+?)</a>').findall(str(div))
		else:
			match = re.compile('href="seriale-(.+?)-online-download\.html" title=".+?".?>(.+?)</a>').findall(str(div))
		
		a = len(match)
		notif('TV Shows',str(a)+' found')
		z = 0
		while z <= int(a - 1):
			addDir(str(i)+'. '+str(match[z][1]),url+'seriale-'+str(match[z][0])+'-online-download.html',2,'')
			z = z + 1
			
			percent = int( ( i * 100 ) / a)
			message = "Loading TV Show " + str(i) + " of " + str(a)
			progress.update(percent, "", message, "")
			if progress.iscanceled():
				break
			i = i + 1
			
	progress.close()

		
def get_tvshow_seasons(name, url):

	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	
	i = 1
	a = ' '
	
	while i < a:
	
		get_thumb = re.compile('<img src=\'(.+?)\' alt=.+?</td>').findall(http_req(url))
		if get_thumb:
			videothumb = siteUrl+get_thumb[0]
		else:
			videothumb = ''

		match = re.compile('<img src=\'.+?\' alt=\'Sezonul (.+?)\'>').findall(http_req(url))
		a = len(match)
		for season_number in match:
			addDir('Season '+str(season_number).zfill(2),url,3,videothumb,name,videothumb)
		
			percent = int( ( i * 100 ) / a)
			message = "Loading season " + str(i) + " of " + str(a)
			progress.update( percent, "", message, "" )
			if progress.iscanceled():
				break
			i = i + 1
			
	progress.close()

		
def get_tvshow_episodes(tvshow_url,season,videoname,videothumb):
	
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	
	i = 1
	a = ' '
	
	while i < a:
		
		m = re.search('[\d]+', season)
		season = m.group(0)

		episodes = re.compile('<td><div .+?>Sezonul '+season+', Episodul (.+?)</div></td><td><a href=\'seriale2-(.+?)-download\.html\'>(.+?)</a></td>').findall(http_req(tvshow_url))
		if episodes:
			a = len(episodes)
		else:
			episodes = re.compile('<td><div .+?>([\d]+)</div></td><td><a href=\'seriale2-(.+?)-download\.html\'>(.+?)</a></td>').findall(http_req(tvshow_url))
		if episodes:
			a = len(episodes)
		else:
			episodes = re.compile('<td><div .+?>Episodul (.+?)</div></td><td><a href=\'seriale2-(.+?)-download\.html\'>(.+?)</a></td>').findall(http_req(tvshow_url))
			a = len(episodes)
		for ep_num,ep_href,ep_name in episodes:
			if ep_name == str(re.findall('(Episodul [-0-9]*)',ep_name)).strip('[]').strip('"\''):
				ep_name = ' '
			addDir('Episode '+ep_num+' '+stringFilter(ep_name),siteUrl+'player-serial-'+ep_href+'-sfast.html',8,videothumb,videoname,videothumb)
			
			percent = int( ( i * 100 ) / a)
			message = "Loading episode " + str(i) + " of " + str(a)
			progress.update(percent, "", message, "")
			if progress.iscanceled():
				break
			i = i + 1
	
	progress.close()
	

def get_cartoons(url):

	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	
	soup = BeautifulSoup(http_req(url))
	div = soup.find("ul", {"id": "ddsubmenu3"})
	
	i = 1
	a = ' '
	
	while i < a:
	
		match = re.compile('href="desene-animate-(.+?)-online-download\.html" title=".+?".?>(.+?)</a>').findall(str(div))
		a = len(match)
		notif('Cartoons',str(a)+' found')
		z = 0
		while z <= int(a - 1):
			addDir(str(i)+'. '+str(match[z][1]),url+'desene-animate-'+str(match[z][0])+'-online-download.html',6,'')
			z = z + 1
			
			percent = int( ( i * 100 ) / a)
			message = "Loading Cartoon " + str(i) + " of " + str(a)
			progress.update(percent, "", message, "")
			if progress.iscanceled():
				break
			i = i + 1
			
	progress.close()


def get_cartoon_seasons(name,url):

	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	i = 1
	a = ' '
	while i < a:
	
		getThumb = re.compile('<img src=\'(.+?)\' alt=.+?</td>').findall(http_req(url))
		if getThumb:
			videothumb = siteUrl+getThumb[0]
		else:
			videothumb = ''
	
		match = re.compile('<img src=\'.+?\' alt=\'Sezonul (.+?)\'>').findall(http_req(url))
		a = len(match)
		for season_number in match:
			addDir('Season '+str(season_number).zfill(2),url,7,videothumb,name,videothumb)

			percent = int( ( i * 100 ) / a)
			message = "Loading season " + str(i) + " of " + str(a)
			progress.update(percent, "", message, "")
			if progress.iscanceled():
				break
			i = i + 1
			
	progress.close()
		

def get_cartoon_episodes(cartoon_url,season,videoname,videothumb):
	
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	i = 1
	a = ' '
	while i < a:
		
		m = re.search('[\d]+', season)
		season = m.group(0)
		episodes = re.compile('<td>Sezonul '+season+', Episodul (.+?)</td><td.+?<a href=\'desene-animate2-(.+?)-download\.html\'>(.+?)</td>').findall(http_req(cartoon_url))
		a = len(episodes)
		for ep_num,ep_href,ep_name in episodes:
			if ep_name == str(re.findall('(Episodul [-0-9]*)',ep_name)).strip('[]').strip('"\''):
				ep_name = ' '
			addDir('Episode '+ep_num+' '+stringFilter(ep_name),siteUrl+'player-serial-'+ep_href+'-sfast.html',8,videothumb,videoname,videothumb)
			
			percent = int( ( i * 100 ) / a)
			message = "Loading episode " + str(i) + " of " + str(a)
			progress.update(percent, "", message, "")
			if progress.iscanceled():
				break
			i = i + 1
	
	progress.close()


def MOVIESORDER(url):
	addDir('Search',url,20,MoviesIcon)
	addDir('By Year',url,11,MoviesIcon)
	addDir('By Genre',url,12,MoviesIcon)


def MOVIESbyYEAR(url):
	match = re.compile('<li><a href="(.+?)" title="Filme online [0-9]+ gratis">Filme online (.+?)</a></li>').findall(http_req(url))
	for link,year in match:
		addDir(str(year),url+link,9,MoviesIcon)


def MOVIESbyGENRE(url):
	match = re.compile('<li><a href="filme-(.+?)-1\.html" title="Filme .+?">(.+?)</a></li>').findall(http_req(url))
	for link,genre in match:
		addDir(str(genreRO2EN(genre)),url+'filme-'+link+'-1.html',9,MoviesIcon)


def get_movies(url):

	match = re.compile('<a href=\'filme.+?-[\d]+\.html\'>([\d]+)</a>').findall(http_req(url))
	pages = [int(x) for x in match]
	maxpage = max(pages)
	
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	
	count = 1
	i = 1
	b = ' '

	while count < b:
	
		while i <= maxpage:
			url = re.sub('-\d\.+','-'+str(i)+'.',url)

			soup = BeautifulSoup(http_req(url))
			div = soup.find("div", {"id": "content"})
			match = re.compile('<h2><a href="filme-(.+?)-online-download\.html" class="titlu">(.+?)</a></h2>').findall(str(div))
			get_thumb = re.compile('<img src="(.+?)" alt=".+?" title=".+?" />').findall(str(div))
			
			z = 0
			a = len(match)
			b = a * maxpage

			while z <= int(a - 1):
				addDir(str(count)+'. '+str(match[z][1]),siteUrl+'filme-'+str(match[z][0])+'-online-download.html',8,siteUrl+get_thumb[z],str(match[z][1]),siteUrl+get_thumb[z])
				z = z + 1
				
				percent = int( ( count * 100 ) / b)
				message = "Loading movie " + str(count) + " of approximately " + str(b)
				progress.update(percent, "", message, "")
				if progress.iscanceled():
					break
				
				count = count + 1
			i = i + 1
		
		notif('Movies',str(count - 1)+' found')
	
	progress.close()


def get_video(url,videoname,videothumb):
	
	quality = ''
	
	if(re.search('filme', url)):
		quality = re.compile('<font color=\'red\'>(.+?)</font></div>').findall(http_req(url))
		movieId = re.search('-([\d]+)-', url)
		movieId = movieId.group(1)
		url = siteUrl+'player-film-'+movieId+'-sfast.html'
	
	progress = xbmcgui.DialogProgress()
	progress.create('Progress', 'Please wait...')
	
	i = 1
	
	while i < 2:
	
		match = re.compile('http:\/\/fastupload\.?r?o?l?\.ro\/?v?i?d?e?o?\/(.+?)\.html').findall(http_req(url))
		url = 'http://superweb.rol.ro/video/'+match[0]+'.html'
		match = re.compile('\'file\': \'(.+?)\',').findall(http_req(url))
		videoLink = match[0]+'|referer='+url
		if(quality == ''):
			addLink(videoname,videoLink,videothumb)
		else:
			addLink(videoname,videoLink,videothumb,quality[0])
		
		percent = int( ( i / 2.0 ) * 100)
		message = "Loading video..."
		progress.update(percent, "", message, "")
		if progress.iscanceled():
			break
		i = i + 1
	
	progress.close()


def SEARCH(cat):

	kb = xbmc.Keyboard('', 'Search', False)
	kb.doModal()
	if (kb.isConfirmed()):
		searchText = kb.getText()
		if searchText == '':
			dialog = xbmcgui.Dialog().ok('Search','There is nothing to search.')
			xbmc.executebuiltin('Notification(There is nothing to search.,Please enter something to search.,5000)')
		else:
			searchText = re.sub(' ','%20',searchText)
			progress = xbmcgui.DialogProgress()
			progress.create('Progress', 'Please wait...')
			i = 1
			a = ' '
			
			soup = BeautifulSoup(http_req(siteUrl+'cauta2.php?text='+searchText+'&submit=Cauta'))
			div = soup.find("div", {"id": "content"})
			
			while i < a:
				if cat == 'all':
					match = re.compile('<h2><a href="(.+?)-(.+?)-online-download\.html" class="titlu">(.+?)</a></h2>').findall(str(div))
					get_thumb = re.compile('<img src="(.+?)" alt=".+?" title=".+?" />').findall(str(div))
				else:
					match = re.compile('<h2><a href="('+cat+')-(.+?)-online-download\.html" class="titlu">(.+?)</a></h2>').findall(str(div))
					get_thumb = re.compile('<a href="'+cat+'-.+?" class="thumb"><img src="(.+?)" alt=".+?" title=".+?" />').findall(str(div))
				
				a = len(match)
				z = 0
				
				while z <= int(a - 1):
					if str(match[z][0]) == 'seriale':
						addDir(str(i)+'. '+str(match[z][2]),url+'seriale-'+str(match[z][1])+'-online-download.html',2,siteUrl+get_thumb[z],str(match[z][2]),siteUrl+get_thumb[z])
					elif str(match[z][0]) == 'filme':
						addDir(str(i)+'. '+str(match[z][2]),url+'filme-'+str(match[z][1])+'-online-download.html',8,siteUrl+get_thumb[z],str(match[z][2]),siteUrl+get_thumb[z])
					z = z + 1

					percent = int( ( i * 100 ) / a)
					message = "Loading " + str(i) + " of " + str(a)
					progress.update( percent, "", message, "" )
					if progress.iscanceled():
						break
					i = i + 1

				notif('Search',str(a)+' found')
			progress.close()


def notif(title,message):
	notification = xbmc.executebuiltin('Notification('+title+','+message+',2000,'+InformationIcon+')')
	return notification


def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
			params = sys.argv[2]
			cleanedparams = params.replace('?','')
			if (params[len(params)-1] == '/'):
				params = params[0:len(params)-2]
			pairsofparams = cleanedparams.split('&')
			param = {}
			for i in range(len(pairsofparams)):
				splitparams = {}
				splitparams = pairsofparams[i].split('=')
				if (len(splitparams)) == 2:
					param[splitparams[0]] = splitparams[1]
	return param



def http_req(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	req.add_header('Accept', ACCEPT)
	response = urllib2.urlopen(req)
	source = response.read()
	response.close()
	return source


def addLink(name,url,iconimage,quality=''):
	ok = True
	if(quality == ''):
		liz = xbmcgui.ListItem('PLAY', iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	else:
		liz = xbmcgui.ListItem('PLAY (Quality:'+quality+')', iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo(type="Video", infoLabels = {"Title": name})
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]),url = url, listitem = liz)
	return ok

	
def addDir(name,url,mode,iconimage,videoname='',videothumb=''):
	u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&videoname="+urllib.quote_plus(videoname)+"&videothumb="+urllib.quote_plus(videothumb)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels = {"Title": name})
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url = u,listitem = liz, isFolder = True)
	return ok


def stringFilter(string):
	if re.sub('&#259;','a',string):
		return re.sub('&#259','a',string)
	elif re.sub('&#259','a',string):
		return re.sub('&#259','a',string)


def genreRO2EN(genre):
	if genre == 'Actiune':
		genre = 'Action'
	elif genre == 'Animatie':
		genre = 'Animation'
	elif genre == 'Aventura':
		genre = 'Adventure'
	elif genre == 'Biografie':
		genre = 'Biography'
	elif genre == 'Comedie':
		genre = 'Comedy'
	elif genre == 'Crima':
		genre = 'Crime'
	elif genre == 'Documentar':
		genre = 'Documentary'
	elif genre == 'Dragoste':
		genre = 'Romance'
	elif genre == 'Familie':
		genre = 'Family'
	elif genre == 'Fantezie':
		genre = 'Fantasy'
	elif genre == 'Istorie':
		genre = 'History'
	elif genre == 'Mafie':
		genre = 'Mafia'
	elif genre == 'Mister':
		genre = 'Mystery'
	elif genre == 'Razboi':
		genre = 'War'
	elif genre == 'Romanesti':
		genre = 'Romanian'
	elif genre == 'Sarbatori':
		genre = 'Holidays'
	elif genre == 'S.F.':
		genre = 'Sci-Fi'
	return genre

		
params = get_params()
url = None
name = None
mode = None
videoname = ""
videothumb = ""


try:
	url = stringFilter(urllib.unquote_plus(params["url"]))
except:
	pass
try:
	name = stringFilter(urllib.unquote_plus(params["name"]))
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	videoname = urllib.unquote_plus(params["videoname"])
	videoname = re.sub('[0-9]+\.',"",videoname)
except:
	pass
try:
	videothumb = urllib.unquote_plus(params["videothumb"])
except:
	pass


print "Mode: "+str(mode)
print "URL: "+str(url)


if mode == None or url == None or len(url) < 1:
	CATEGORIES()
       
elif mode == 1:
	get_tvshows(url)

elif mode == 2:
	get_tvshow_seasons(name,url)
		
elif mode == 3:
	get_tvshow_episodes(url,name,videoname,videothumb)

elif mode == 4:
	TVSHOWSORDER(url)
	
elif mode == 5:
	get_cartoons(url)

elif mode == 6:
	get_cartoon_seasons(name,url)	

elif mode == 7:
	get_cartoon_episodes(url,name,videoname,videothumb)

elif mode == 8:
	print ""+url
	get_video(url,videoname,videothumb)
	
elif mode == 9:
	get_movies(url)
	
elif mode == 10:
	MOVIESORDER(url)
	
elif mode == 11:
	MOVIESbyYEAR(url)

elif mode == 12:
	MOVIESbyGENRE(url)

elif mode == 20:
	SEARCH('filme')
	
elif mode == 21:
	SEARCH('seriale')

elif mode == 22:
	SEARCH('all')

elif mode == 30:
	get_tvshows(url,name)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
