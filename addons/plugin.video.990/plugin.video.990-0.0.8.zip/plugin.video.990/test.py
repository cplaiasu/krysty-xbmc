import urllib, urllib2


url = "http://superweb.rol.ro/video/5c0113de3362957707b560225992ca31.html"
file = "http://sv6.fastupload.ro/download/d9f729e930de8cb152fbaf60b131d59e/52bcc6e9/flv/5c0113de3362957707b560225992ca31.flv"


USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.2) Gecko/2008091620 Firefox/3.0.2'
ACCEPT = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'

def http_req(url,referer=""):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    req.add_header('Accept', ACCEPT)
    if referer:
        req.add_header('Referer', referer)
    response = urllib2.urlopen(req)
    source = response.read()
    response.close()
    return source

