import xbmcaddon, util

addon = xbmcaddon.Addon('plugin.video.antena3')

util.playMedia(addon.getAddonInfo('name'), addon.getAddonInfo('icon'), 'rtmp://93.115.84.226/live playpath=a3 swfUrl=http://ivm.inin.ro/swf/player_licensed.swf pageUrl=http://www.antena3.ro/live.php live=true')